Write the following commands-
```
git clone https://github.com/Abhishek-Ranjan-16/aivshumancli.git
cd aivshumancli
pip install -r requirements.txt
python app.py <input_file_path> <output_file_directory>
```

Example for last one in this case:
```
python app.py dataset/dataset.jsonl dataset
```
Now we are talking.
